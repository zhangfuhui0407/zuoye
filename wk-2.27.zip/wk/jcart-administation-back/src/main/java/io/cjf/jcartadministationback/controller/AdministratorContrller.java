package io.cjf.jcartadministationback.controller;

import io.cjf.jcartadministationback.dto.in.*;
import io.cjf.jcartadministationback.dto.out.AdministratorGetProfileOutDTO;
import io.cjf.jcartadministationback.dto.out.AdministratorListOutDTO;
import io.cjf.jcartadministationback.dto.out.AdministratorShowOutDTO;
import io.cjf.jcartadministationback.dto.out.PageOutDTO;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/administrator")
public class AdministratorContrller {

    @GetMapping("/login")
    public String login(AdministratorLoginlnDTO administratorLoginlnDTO){
        return null;
    }

    @GetMapping("/getProfile")
    public AdministratorGetProfileOutDTO getProfile(Integer adminstratorId){
        return null;
    }

    @PostMapping("/updateProdfile")
    public void updateProdfile(@RequestBody AdministratorUpdateProfileInDTO administratorUpdateProfileInDTO){
        
    }

    @GetMapping("/getPwdResetCode")
    public String getPwdResetCode(@RequestParam String email){
        return null;
    }

    @PostMapping("/resetPwd")
    public void resetPwd(@RequestBody AdministratorResetPwdDTO administratorResetPwdDTO){

    }

    @GetMapping("/getList")
    public PageOutDTO<AdministratorListOutDTO> getList(@RequestParam Integer pageNum){
        return null;
    }

    @GetMapping("/getById")
    public AdministratorShowOutDTO getById(@RequestParam Integer administratorId){
        return null;
    }

    @PostMapping("/create")
    public Integer create(@RequestBody AdministratorCreaterInDTO administratorCreaterInDTO){
        return null;
    }

    @PostMapping("upload")
    public void upload(@RequestBody AdministratorUpdateInDTO administratorUpdateInDTO){

    }

    @PostMapping("/delete")
    public void delete(@RequestBody Integer adminstratorId){

    }

    @PostMapping("/betchDelete")
    public void betchDelete(@RequestBody List<Integer> administratorIds){

    }
}
