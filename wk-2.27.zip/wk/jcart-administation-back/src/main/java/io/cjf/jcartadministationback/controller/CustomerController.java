package io.cjf.jcartadministationback.controller;

import io.cjf.jcartadministationback.dto.in.CustomerSearchInDTO;
import io.cjf.jcartadministationback.dto.out.CustomerListOutDTO;
import io.cjf.jcartadministationback.dto.out.CustomerShowOutDTO;
import io.cjf.jcartadministationback.dto.out.PageOutDTO;
import org.springframework.cglib.core.TinyBitSet;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/customer")
public class CustomerController {

    @GetMapping("/search")
    public PageOutDTO<CustomerListOutDTO> search(CustomerSearchInDTO customerSearchInDTO,
                                                 @RequestParam Integer pageNum){
        return null;
    }

    @GetMapping("/getById")
    public CustomerShowOutDTO getById(@RequestParam Integer customerId){
        return null;
    }

    @PostMapping("/disable")
    public void disable(@RequestParam Integer customerId){

    }
}
