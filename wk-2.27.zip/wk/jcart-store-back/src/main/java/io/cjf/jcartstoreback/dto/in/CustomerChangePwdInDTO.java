package io.cjf.jcartstoreback.dto.in;

public class CustomerChangePwdInDTO {
    private String originpwd;
    private String newpwd;

    public String getOriginpwd() {
        return originpwd;
    }

    public void setOriginpwd(String originpwd) {
        this.originpwd = originpwd;
    }

    public String getNewpwd() {
        return newpwd;
    }

    public void setNewpwd(String newpwd) {
        this.newpwd = newpwd;
    }
}
