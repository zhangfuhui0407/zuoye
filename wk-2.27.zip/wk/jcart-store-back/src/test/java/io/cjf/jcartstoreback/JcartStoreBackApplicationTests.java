package io.cjf.jcartstoreback;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JcartStoreBackApplicationTests {

    @Test
    void contextLoads() {
    }

}
