package io.cjf.jcartadministationback.controller;

import io.cjf.jcartadministationback.dto.in.ProductCreateInDTO;
import io.cjf.jcartadministationback.dto.in.ProductSearchInDTO;
import io.cjf.jcartadministationback.dto.in.ProductUpdateInDTO;
import io.cjf.jcartadministationback.dto.out.PageOutDTO;
import io.cjf.jcartadministationback.dto.out.ProductListOutDTO;
import io.cjf.jcartadministationback.dto.out.ProductShowOutDTO;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/product")
public class ProductController {

    @GetMapping("/search")
    public PageOutDTO<ProductListOutDTO> search(ProductSearchInDTO productSearchInDTO,
                                                @RequestParam Integer pageNum){
        return null;
    }

    @PostMapping("/create")
    public Integer create(@RequestBody ProductCreateInDTO productCreateInDTO){
        return null;
    }

    @PostMapping("/upload")
    public void upload(@RequestBody ProductUpdateInDTO productUpdateInDTO){

    }

    @GetMapping("/getById")
    public ProductShowOutDTO getById(@RequestParam Integer productId){
        return null;
    }
}
