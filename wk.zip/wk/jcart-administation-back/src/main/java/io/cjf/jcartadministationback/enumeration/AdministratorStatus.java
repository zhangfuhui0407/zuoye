package io.cjf.jcartadministationback.enumeration;

public enum AdministratorStatus {
    Disable,
    Enable
}
