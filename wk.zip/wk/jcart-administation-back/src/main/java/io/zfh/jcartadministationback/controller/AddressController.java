package io.zfh.jcartadministationback.controller;

import io.zfh.jcartadministationback.constant.ClientExceptionConstant;
import io.zfh.jcartadministationback.exception.ClientException;
import io.zfh.jcartadministationback.dto.out.AddressListOutDTO;
import io.zfh.jcartadministationback.dto.out.AddressShowOutDTO;
import io.zfh.jcartadministationback.po.Address;
import io.zfh.jcartadministationback.service.AddressService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/address")
@CrossOrigin
public class AddressController {

    @Autowired
    private AddressService addressService;

    @GetMapping("/getListByCustomerId")
    public List<AddressListOutDTO> getListByCustomerId(@RequestParam Integer customerId){
        //根据客户id查出客户所有地址信息
        List<Address> addresses = addressService.getByCustomerId(customerId);
        //转值--------利用箭头函数
        List<AddressListOutDTO> addressListOutDTOS = addresses.stream().map(address -> {
            AddressListOutDTO addressListOutDTO = new AddressListOutDTO();
            addressListOutDTO.setAddressId(address.getAddressId());
            addressListOutDTO.setReceiverName(address.getReceiverName());
            addressListOutDTO.setReceiverMobile(address.getReceiverMobile());
            addressListOutDTO.setContent(address.getContent());
            addressListOutDTO.setTag(address.getTag());
            return addressListOutDTO;
        }).collect(Collectors.toList());
        return addressListOutDTOS;
    }

    @GetMapping("/getById")
    public AddressShowOutDTO getById(@RequestParam Integer addressId) throws ClientException {
        //根据地址id查询地址信息
        Address address = addressService.getById(addressId);
        //判断查询结果是否为空   为空报异常
        if(address == null){
            System.out.println("空指针");
            throw new ClientException(ClientExceptionConstant.ADDRESSSTOP_RETURN_NULL_ID,ClientExceptionConstant.ADDRESSSTOP_RETURN_NULL);
        }
        //结果不为空进行转值并返回
        AddressShowOutDTO addressShowOutDTO = new AddressShowOutDTO();
        addressShowOutDTO.setAddressId(address.getAddressId());
        addressShowOutDTO.setReceiverName(address.getReceiverName());
        addressShowOutDTO.setReceiverMobile(address.getReceiverMobile());
        addressShowOutDTO.setContent(address.getContent());
        addressShowOutDTO.setTag(address.getTag());
        return addressShowOutDTO;
    }

}
