package io.zfh.jcartadministationback.enumeration;

public enum AdministratorStatus {
    Disable,
    Enable
}
