package io.zfh.jcartadministationback.service;

import io.zfh.jcartadministationback.po.Address;

import java.util.List;

public interface AddressService {

    Address getById(Integer addressId);

    List<Address> getByCustomerId(Integer customerId);

}
