package io.zfh.jcartadministationback.controller;

import com.github.pagehelper.Page;
import io.zfh.jcartadministationback.dto.in.ProductCreateInDTO;
import io.zfh.jcartadministationback.dto.in.ProductSearchInDTO;
import io.zfh.jcartadministationback.dto.in.ProductUpdateInDTO;
import io.zfh.jcartadministationback.dto.out.PageOutDTO;
import io.zfh.jcartadministationback.dto.out.ProductListOutDTO;
import io.zfh.jcartadministationback.dto.out.ProductShowOutDTO;
import io.zfh.jcartadministationback.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/product")
@CrossOrigin
public class ProductController {

    @Autowired
    private ProductService productService;

    @GetMapping("/search")
    public PageOutDTO<ProductListOutDTO> search(ProductSearchInDTO productSearchInDTO,
                                                @RequestParam(required = false, defaultValue = "1") Integer pageNum) {
        //查询商品所有信息并进行分页处理
        Page<ProductListOutDTO> page = productService.search(pageNum);

        //转值并返回
        PageOutDTO<ProductListOutDTO> pageOutDTO = new PageOutDTO<>();
        pageOutDTO.setTotal(page.getTotal());
        pageOutDTO.setPageSize(page.getPageSize());
        pageOutDTO.setPageNum(page.getPageNum());
        pageOutDTO.setList(page);

        return pageOutDTO;
    }

    @GetMapping("/getById")
    public ProductShowOutDTO getById(@RequestParam Integer productId) {
        return productService.getById(productId);
    }

    @PostMapping("/create")
    public Integer create(@RequestBody ProductCreateInDTO productCreateInDTO) {
        return productService.create(productCreateInDTO);
    }

    @PostMapping("/update")
    public void update(@RequestBody ProductUpdateInDTO productUpdateInDTO) {
        productService.update(productUpdateInDTO);
    }

    @PostMapping("/delete")
    public void delete(@RequestBody Integer productId) {
        productService.delete(productId);
    }

    @PostMapping("/batchDelete")
    public void batchDelete(@RequestBody List<Integer> productIds) {
        productService.batchDelete(productIds);
    }
}
