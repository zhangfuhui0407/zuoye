package io.zfh.jcartadministationback.service;

import com.github.pagehelper.Page;
import io.zfh.jcartadministationback.po.Customer;
import io.zfh.jcartadministationback.dto.in.CustomerSetStatusInDTO;

public interface CustomerService {

    Page<Customer> search(Integer pageNum);

    Customer getById(Integer customerId);

    void setStatus(CustomerSetStatusInDTO customerSetStatusInDTO);

}
