package io.zfh.jcartadministationback.vo;

public class AdministratorLoginVO {
    private Integer administratorId;
    private String username;

    public Integer getAdministratorId() {
        return administratorId;
    }

    public void setAdministratorId(Integer administratorId) {
        this.administratorId = administratorId;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
}
