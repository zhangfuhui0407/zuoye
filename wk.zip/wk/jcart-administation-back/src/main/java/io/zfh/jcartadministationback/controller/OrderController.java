package io.zfh.jcartadministationback.controller;


import com.github.pagehelper.Page;
import io.zfh.jcartadministationback.dto.in.OrderSearchinDTO;
import io.zfh.jcartadministationback.dto.out.*;
import io.zfh.jcartadministationback.dto.out.PageOutDTO;
import io.zfh.jcartadministationback.service.OrderService;
import io.zfh.jcartadministationback.dto.out.OrderListOutDTO;
import io.zfh.jcartadministationback.dto.out.OrderShipShowOutDTO;
import io.zfh.jcartadministationback.dto.out.OrderlnvoiceShowOutDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/order")
@CrossOrigin
public class OrderController {

    @Autowired
    private OrderService orderService;

    @GetMapping("/search")
    public PageOutDTO<OrderListOutDTO> search(OrderSearchinDTO orderSearchInDTO,
                                              @RequestParam(required = false, defaultValue = "1") Integer pageNum) {
        //查询所有订单信息
        Page<OrderListOutDTO> page = orderService.search(pageNum);

        PageOutDTO<OrderListOutDTO> pageOutDTO = new PageOutDTO<>();
        pageOutDTO.setTotal(page.getTotal());
        pageOutDTO.setPageSize(page.getPageSize());
        pageOutDTO.setPageNum(page.getPageNum());
        pageOutDTO.setList(page);

        return pageOutDTO;
    }

    @GetMapping("/getById")
    public OrdershowOutDTO getById(@RequestParam Long orderId) {
        return orderService.getById(orderId);
    }

    @GetMapping("/getInvoiceInfo")
    public OrderlnvoiceShowOutDTO getInvoiceInfo(@RequestParam Long orderId) {
        return null;
    }

    @GetMapping("/getShipInfo")
    public OrderShipShowOutDTO getShipInfo(@RequestParam Long orderId) {
        return null;
    }

}
