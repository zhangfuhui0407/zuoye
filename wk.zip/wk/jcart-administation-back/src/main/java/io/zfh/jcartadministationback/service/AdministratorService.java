package io.zfh.jcartadministationback.service;

import com.github.pagehelper.Page;
import io.zfh.jcartadministationback.po.Administrator;

import java.util.List;

public interface AdministratorService {
    public Administrator getByUsername(String username);

    Administrator getById(Integer administratorId);

    Integer create(Administrator administrator);

    void update(Administrator administrator);

    void delete(Integer administratorId);

    void batchDelete(List<Integer> administratorIds);

    Page<Administrator> getList(Integer pageNum);
}
