package io.zfh.jcartadministationback.service.impl;

import io.zfh.jcartadministationback.dao.OrderHistoryMapper;
import io.zfh.jcartadministationback.po.Order;
import io.zfh.jcartadministationback.po.OrderHistory;
import io.zfh.jcartadministationback.service.OrderHistoryService;
import io.zfh.jcartadministationback.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

@Service
public class OrderHistoryServiceImpl implements OrderHistoryService {

    @Autowired
    private OrderHistoryMapper orderHistoryMapper;

    @Autowired
    private OrderService orderService;

    @Override
    public List<OrderHistory> getByOrderId(Long orderId) {
        return orderHistoryMapper.selectByOrderId(orderId);
    }

    @Override
    @Transactional
    public Long create(OrderHistory orderHistory) {
        //添加订单历史信息
        orderHistoryMapper.insertSelective(orderHistory);
        Order order = new Order();
        order.setOrderId(orderHistory.getOrderId());
        order.setStatus(orderHistory.getOrderStatus());
        order.setUpdateTime(new Date());
        //对订单信息进行更新
        orderService.update(order);
        Long orderHistoryId = orderHistory.getOrderHistoryId();
        //返回主键id
        return orderHistoryId;
    }
}
