package io.zfh.jcartadministationback.service.impl;

import io.zfh.jcartadministationback.dao.ReturnHistoryMapper;
import io.zfh.jcartadministationback.po.Return;
import io.zfh.jcartadministationback.po.ReturnHistory;
import io.zfh.jcartadministationback.service.ReturnHistoryService;
import io.zfh.jcartadministationback.service.ReturnService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

@Service
public class ReturnHistoryServiceImpl implements ReturnHistoryService {

    @Autowired
    private ReturnHistoryMapper returnHistoryMapper;

    @Autowired
    private ReturnService returnService;

    @Override
    public List<ReturnHistory> getListByReturnId(Integer returnId) {
        return returnHistoryMapper.selectListByReturnId(returnId);
    }

    @Override
    @Transactional
    public Long create(ReturnHistory returnHistory) {
        //对退货历史信息进行添加
        returnHistoryMapper.insertSelective(returnHistory);
        Long returnHistoryId = returnHistory.getReturnHistoryId();

        //更新退货信息
        Return aReturn = new Return();
        aReturn.setReturnId(returnHistory.getReturnId());
        aReturn.setUpdateTime(new Date());
        returnService.update(aReturn);

        return returnHistoryId;
    }
}
