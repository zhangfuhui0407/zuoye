package io.zfh.jcartadministationback.service;

import com.github.pagehelper.Page;
import io.zfh.jcartadministationback.dto.out.OrderShowOutDTO;
import io.zfh.jcartadministationback.po.Order;
import io.zfh.jcartadministationback.dto.out.OrderListOutDTO;

public interface OrderService {

    Page<OrderListOutDTO> search(Integer pageNum);

    OrderShowOutDTO getById(Long orderId);

    void update(Order order);

}
