package io.zfh.jcartadministationback.service;

import com.github.pagehelper.Page;
import io.zfh.jcartadministationback.dto.out.OrderListOutDTO;
import io.zfh.jcartadministationback.dto.out.OrdershowOutDTO;
import io.zfh.jcartadministationback.po.Order;

public interface OrderService {

    Page<OrderListOutDTO> search(Integer pageNum);

    OrdershowOutDTO getById(Long orderId);

    void update(Order order);

}
