const RoutePage = {
    template: ``
}