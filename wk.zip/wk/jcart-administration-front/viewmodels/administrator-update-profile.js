var app = new Vue({
    el: '#app',
    data: {
        administratorId:'',
        username:'',
        realName:'',
        email:'',
        avatarUrl:'',
        createTimestamp:''
    },
    mounted(){
        console.log("调用方法");
        this.getMyProfile();
    },
    methods:{
        handleupdateclick(){
                console.log('更新')
            },
            getMyProfile(){
                axios.get('/administrator/getProfile')
                    .then(function(response){
                        console.log(response);
                        var me = response.data;
                        app.administratorId = me.administratorId;
                        app.username = me.username;
                        app.realName = me.realName;
                        app.email = me.email;
                        app.avatarUrl = me.avatarUrl;
                        app.createTimestamp = me.createTimestamp;
                    })
                    .catch(function(error){
                        console.log(error);
                        alert("更新失败")
                    });
            }
        }
})