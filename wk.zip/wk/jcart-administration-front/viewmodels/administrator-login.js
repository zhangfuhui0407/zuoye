var app = new Vue({
    el: '#login',
    data: {
        username:'',
        password:''
    },
    methods:{
        handleLoginclick(){
            console.log('登录')
            this.loginAdministrator();
        },
        loginAdministrator(){
            axios.get('/administrator/login',{
                params:{
                    username: this.username,
                    password: this.password
                }
            })
                .then(function(response){
                    console.log(response);
                    var dto = response.data;
                    localStorage['jcartToken'] = dto.Token;
                    localStorage['expireTimestamp'] = dto.expireTimestamp;
                    alert("登录成功")
                })
                .catch(function(error){
                    console.log(error);
                    alert("登录失败")
                });
        }
    }
})