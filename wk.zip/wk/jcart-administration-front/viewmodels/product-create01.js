var app = new Vue({
    el: '#app01',
    data: {
        productCode: '',
        productName: '',
        price: '',
        discount: '',
        stockQuantity: '',
        rewordPoints: '',
        sortOrder: '',
        description: '',
        selectedStatus: 1,
        selectedMainPic: '',
        mainPicUrl: '',
        selectedOtherPics: [],
        otherPicUrls: [],
        statuses:[
            {value:0,label:'上架'},
            {value:1,label:'下架'},
            {value:2,label:'待审核'}
        ],
        mainFileList:[]
    },
    methods:{
        handleCreateClick(){
            console.log('create click');
            this.createProduct();
        },
        handleUploadMainClick(){
            console.log('上传图片');
            this.uploadMainImage();
        },
        handleOnMainChange(val){
            this.selectMainPic = val.raw;
        },
        uploadMainImage() {
            var formData = new FormData();
            formData.append("image", this.selectedMainPic);

            axios.post('/image/upload', formData, {
                headers: {
                    'Content-Type': 'multipart/form-data'
                }
            })
                .then(function (response) {
                    console.log(response);
                    app.mainPicUrl = response.data;
                    alert('上传成功');
                })
                .catch(function (error) {
                    console.log(error);
                    alert('上传失败');
                });
        },
        createProduct(){
            axios.post('/product/create',{
                ProductCode:this.ProductCode,
                ProductName:this.ProductName,
                price:this.price,
                discount:this.discount,
                stoclQuantity:this.stockQuantity,
                status:this.status,
                mainPicUrl:this.mainPicUrl,
                rewordPoints:this.rewordPoints,
                sortOrder:this.sortOrder,
                description:this.description,
                otherPicUrls:this.otherPicUrls
            })
                .then(function(response){
                    console.log(response);
                    alert("创建成功")
                })
                .catch(function(error){
                    console,log(error);
                })
        }
    }
})