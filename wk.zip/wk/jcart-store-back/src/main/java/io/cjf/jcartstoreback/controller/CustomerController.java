package io.cjf.jcartstoreback.controller;

import io.cjf.jcartstoreback.dto.in.CustomerRegisterInDTO;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/customer")
public class CustomerController {

    @PostMapping("/register")
    private Integer register(@RequestBody CustomerRegisterInDTO customerRegisterInDTO){
        return null;
    }

    @GetMapping("/login")
    public String login(){

    }

}
