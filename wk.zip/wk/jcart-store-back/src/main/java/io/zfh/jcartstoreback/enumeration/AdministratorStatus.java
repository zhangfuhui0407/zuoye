package io.zfh.jcartstoreback.enumeration;

public enum AdministratorStatus {
    Disable,
    Enable
}
