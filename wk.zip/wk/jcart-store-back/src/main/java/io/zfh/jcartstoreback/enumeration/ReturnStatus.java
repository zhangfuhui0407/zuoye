package io.zfh.jcartstoreback.enumeration;

public enum ReturnStatus {
    ToProcess,
    ToReceiveBack,
    Processing,
    Completed,
    Denied
}
