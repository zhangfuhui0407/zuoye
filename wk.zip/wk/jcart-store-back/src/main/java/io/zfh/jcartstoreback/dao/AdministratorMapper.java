package io.zfh.jcartstoreback.dao;

import com.github.pagehelper.Page;
import io.zfh.jcartstoreback.po.Administrator;

import java.util.List;

public interface AdministratorMapper {
    int deleteByPrimaryKey(Integer administratorId);

    int insert(Administrator record);

    int insertSelective(Administrator record);

    Administrator selectByPrimaryKey(Integer administratorId);

    int updateByPrimaryKeySelective(Administrator record);

    int updateByPrimaryKey(Administrator record);

    Page<Administrator> selectList();

    Administrator selectByEmail(String email);

    Administrator selectByUsername(String username);

    void batchDelete(List<Integer> administratorIds);
}