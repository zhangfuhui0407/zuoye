package io.zfh.jcartstoreback.service;

import com.github.pagehelper.Page;
import io.zfh.jcartstoreback.dto.in.OrderCheckoutInDTO;
import io.zfh.jcartstoreback.dto.out.OrderShowOutDTO;
import io.zfh.jcartstoreback.po.Order;

public interface OrderService {

    Long checkout(OrderCheckoutInDTO orderCheckoutInDTO,
                  Integer customerId);

    Page<Order> getByCustomerId(Integer pageNum, Integer customerId);

    OrderShowOutDTO getById(Long orderId);
}
