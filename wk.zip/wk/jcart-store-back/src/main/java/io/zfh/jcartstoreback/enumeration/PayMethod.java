package io.zfh.jcartstoreback.enumeration;

public enum PayMethod {
    CashOnDelivery,
    DebitCard,
    CreditCart,
    Wepay,
    Alipay
}
