package io.zfh.jcartstoreback.enumeration;

public enum ReturnAction {
    ReturnBack,
    ExchangeNew,
    ProductFix
}
