package io.zfh.jcartstoreback.enumeration;

public enum CustomerStatus {
    Disable,
    Enable,
    Unsafe
}
