package io.zfh.jcartstoreback.enumeration;

public enum ShipMethod {
    EMS,
    SF,
    YT,
    ZTO,
    STO
}
