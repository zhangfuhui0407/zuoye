package io.cjf.jcartadministrationback.enumeration;

public enum AdministratorStatus {
    Disable,
    Enable
}
