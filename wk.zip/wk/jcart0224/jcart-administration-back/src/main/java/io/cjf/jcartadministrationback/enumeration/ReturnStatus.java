package io.cjf.jcartadministrationback.enumeration;

public enum ReturnStatus {
    ToProcess,
    ToReceiveBack,
    Processing,
    Completed,
    Denied
}
