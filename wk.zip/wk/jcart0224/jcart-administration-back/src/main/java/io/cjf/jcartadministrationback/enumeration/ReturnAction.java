package io.cjf.jcartadministrationback.enumeration;

public enum ReturnAction {
    ReturnBack,
    ExchangeNew,
    ProductFix
}
