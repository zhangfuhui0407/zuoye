package io.cjf.jcartstoreback.enumeration;

public enum ShipMethod {
    EMS,
    SF,
    YT,
    ZTO,
    STO
}
