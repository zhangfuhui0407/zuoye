package io.cjf.jcartstoreback.enumeration;

public enum PayMethod {
    CashOnDelivery,
    DebitCard,
    CreditCart,
    Wepay,
    Alipay
}
