package io.cjf.jcartstoreback.enumeration;

public enum ReturnReason {
    Expired,
    OrderError,
    ProductError,
    QuanlityIssue
}
