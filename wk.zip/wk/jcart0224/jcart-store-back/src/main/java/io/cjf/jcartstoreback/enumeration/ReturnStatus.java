package io.cjf.jcartstoreback.enumeration;

public enum ReturnStatus {
    ToProcess,
    ToGetBackProduct,
    Processing,
    Completed
}
