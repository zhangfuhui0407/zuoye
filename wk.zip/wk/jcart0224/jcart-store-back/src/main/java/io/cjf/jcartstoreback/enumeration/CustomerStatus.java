package io.cjf.jcartstoreback.enumeration;

public enum CustomerStatus {
    Disable,
    Enable,
    Unsafe
}
