package io.cjf.jcartstoreback.dto.in;

public class AddressCreateInDTO {
    private String receicerName;
    private String receiverMobile;
    private String content;
    private String tag;

    public String getReceicerName() {
        return receicerName;
    }

    public void setReceicerName(String receicerName) {
        this.receicerName = receicerName;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getReceiverMobile() {
        return receiverMobile;
    }

    public void setReceiverMobile(String receiverMobile) {
        this.receiverMobile = receiverMobile;
    }
}
