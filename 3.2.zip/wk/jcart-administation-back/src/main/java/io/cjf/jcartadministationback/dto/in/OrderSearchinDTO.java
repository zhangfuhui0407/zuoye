package io.cjf.jcartadministationback.dto.in;

public class OrderSearchinDTO {
    private Long orderId;
    private String customertNme;
    private Byte status;
    private Double totalPice;

    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public String getCustomertNme() {
        return customertNme;
    }

    public void setCustomertNme(String customertNme) {
        this.customertNme = customertNme;
    }

    public Byte getStatus() {
        return status;
    }

    public void setStatus(Byte status) {
        this.status = status;
    }

    public Double getTotalPice() {
        return totalPice;
    }

    public void setTotalPice(Double totalPice) {
        this.totalPice = totalPice;
    }
}
