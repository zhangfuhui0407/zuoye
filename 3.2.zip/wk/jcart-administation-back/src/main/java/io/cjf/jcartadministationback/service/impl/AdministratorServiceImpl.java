package io.cjf.jcartadministationback.service.impl;

import com.github.pagehelper.Page;
import io.cjf.jcartadministationback.dao.AdministratorMapper;
import io.cjf.jcartadministationback.po.Administrator;
import io.cjf.jcartadministationback.service.AdministratorService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AdministratorServiceImpl implements AdministratorService {

    @Autowired
    private AdministratorMapper administratorMapper;

    @Override
    public Administrator getByUsername(String username) {
        return administratorMapper.getByUsername(username);
    }

    @Override
    public Administrator getById(Integer administratorId) {
        return administratorMapper.selectByPrimaryKey(administratorId);
    }

    @Override
    public Integer create(Administrator administrator) {
        return null;
    }

    @Override
    public void update(Administrator administrator) {

    }

    @Override
    public void delete(Integer administratorId) {

    }

    @Override
    public void batchDelete(List<Integer> administratorIds) {

    }

    @Override
    public Page<Administrator> getList(Integer pageNum) {
        return null;
    }
}
